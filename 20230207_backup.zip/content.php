<!-- -->


<?php
/* panggil file database.php untuk koneksi ke database */
require_once "config/database.php";
/* panggil file fungsi tambahan */
require_once "config/fungsi_rupiah.php";
require_once "config/fungsi_tanggal.php";

// fungsi untuk pengecekan status login user 
// jika user belum login, alihkan ke halaman login dan tampilkan pesan = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])){
	echo "<meta http-equiv='refresh' content='0; url=index.php?alert=1'>";
}
// jika user sudah login, maka jalankan perintah untuk pemanggilan file halaman konten
else {
	// jika halaman konten yang dipilih dashboard, panggil file view dashboard
	if ($_GET['module'] == 'dashboard') {
		include "modules/dashboard/view.php";
	}
// -----------------------------------------------------------------------------	
	
// jika halaman konten yang dipilih data warga, panggil file warga utk user warga
	elseif ($_GET['module'] == 'warga') {
		include "modules/warga/view2.php";
	}


	elseif ($_GET['module'] == 'warga' && $_SESSION['level']=='warga') {
		include "modules/warga/view2.php";
	}	


// -----------------------------------------------------------------------------	

// jika halaman konten yang dipilih data iuran sampah, panggil file iuran sampah utk user warga
	elseif ($_GET['module'] == 'iuran-sampah' && $_SESSION['level']=='warga') {
		include "modules/iuran-sampah/view2.php";
	}


	elseif ($_GET['module'] == 'iuran-sampah') {
		include "modules/iuran-sampah/view.php";
	}
	
	elseif ($_GET['module'] == 'form_iuran-sampah') {
		include "modules/iuran-sampah/form.php";
	}
	

// -----------------------------------------------------------------------------


	// jika halaman konten yang dipilih penerimaan, panggil file view penerimaan
	elseif ($_GET['module'] == 'penerimaan') {
		include "modules/penerimaan/view.php";
	}
	
		// jika halaman konten yang dipilih penerimaan, panggil file penerimaan utk user warga
	elseif ($_GET['module'] == 'penerimaan2' && $_SESSION['level']=='warga') {
		include "modules/penerimaan/view2.php";
	}
	
	
	
		// jika halaman konten yang dipilih pengeluaran, panggil file pengeluaran utk user warga
	elseif ($_GET['module'] == 'pengeluaran2' && $_SESSION['level']=='warga') {
		include "modules/pengeluaran/view2.php";
	}
	

	// jika halaman konten yang dipilih form penerimaan, panggil file form penerimaan
	elseif ($_GET['module'] == 'form_penerimaan') {
		include "modules/penerimaan/form.php";
	}
	
	// -----------------------------------------------------------------------------
	
	// jika halaman konten yang dipilih pengeluaran, panggil file view pengeluaran
	elseif ($_GET['module'] == 'pengeluaran') {
		include "modules/pengeluaran/view.php";
	}

	// jika halaman konten yang dipilih form pengeluaran, panggil file form pengeluaran
	elseif ($_GET['module'] == 'form_pengeluaran') {
		include "modules/pengeluaran/form.php";
	}
	// -----------------------------------------------------------------------------
	
	// jika halaman konten yang dipilih laporan penerimaan, panggil file view laporan penerimaan
	elseif ($_GET['module'] == 'lap_penerimaan') {
		include "modules/lap-penerimaan/view.php";
	}

	// jika halaman konten yang dipilih laporan pengeluaran, panggil file view laporan pengeluaran
	elseif ($_GET['module'] == 'lap_pengeluaran') {
		include "modules/lap-pengeluaran/view.php";
	}

	// jika halaman konten yang dipilih laporan rekapitulasi, panggil file view laporan rekapitulasi
	elseif ($_GET['module'] == 'lap_rekapitulasi') {
		include "modules/lap-rekapitulasi/view.php";
	}
	
	
		// jika halaman konten yang dipilih laporan iuran sampah, panggil file view laporan iuran sampah
	elseif ($_GET['module'] == 'lap_iuransampah') {
		include "modules/lap-iuransampah/view.php";
	}
	
	// -----------------------------------------------------------------------------
	
	// jika halaman konten yang dipilih grafik, panggil file view grafik
	elseif ($_GET['module'] == 'grafik') {
		include "modules/grafik/view.php";
	}
	// -----------------------------------------------------------------------------
	
	// jika halaman konten yang dipilih user, panggil file view user
	elseif ($_GET['module'] == 'user' && $_SESSION['level']=='admin') {
		include "modules/user/view.php";
	}

	// jika halaman konten yang dipilih form user, panggil file form user
	elseif ($_GET['module'] == 'form_user' && $_SESSION['level']=='admin') {
		include "modules/user/form.php";
	}
	// -----------------------------------------------------------------------------

	// jika halaman konten yang dipilih profil, panggil file view profil
	elseif ($_GET['module'] == 'profil') {
		include "modules/profil/view.php";
	}

	// jika halaman konten yang dipilih form profil, panggil file form profil
	elseif ($_GET['module'] == 'form_profil') {
		include "modules/profil/form.php";
	}
	// -----------------------------------------------------------------------------
	
	// jika halaman konten yang dipilih password, panggil file view password
	elseif ($_GET['module'] == 'password') {
		include "modules/password/view.php";
	}
}
?>