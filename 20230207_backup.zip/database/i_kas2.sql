-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 30 Jun 2019 pada 13.32
-- Versi server: 5.6.44
-- Versi PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pkas`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `is_kas`
--

CREATE TABLE `is_kas` (
  `no_kwitansi` varchar(7) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `penerimaan` int(11) NOT NULL DEFAULT '0',
  `pengeluaran` int(11) NOT NULL DEFAULT '0',
  `created_user` smallint(6) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `is_kas`
--

INSERT INTO `is_kas` (`no_kwitansi`, `tanggal`, `keterangan`, `penerimaan`, `pengeluaran`, `created_user`, `created_date`) VALUES
('001', '2019-06-26', 'fee', 20000000, 0, 1, '2019-06-26 14:33:15'),
('77777', '2019-06-02', 'fee Marketing Vlatava 2', 16000000, 0, 1, '2019-06-02 10:51:33'),
('K000001', '2016-08-03', 'Lorem ipsum dolor sit amet', 0, 200000, 1, '2016-08-03 12:23:14'),
('K000002', '2016-08-10', 'At quia quaerat asperiores', 0, 100000, 1, '2016-08-10 10:49:59'),
('K000003', '2016-08-15', 'quaerat asperiores ipsum', 0, 250000, 1, '2016-11-20 10:57:15'),
('M000001', '2016-08-01', 'Consectetur adipisicing elit', 1000000, 0, 1, '2016-08-01 12:23:14'),
('M000002', '2016-08-07', 'Optio corporis quae nulla', 500000, 0, 1, '2016-08-07 12:24:27'),
('M000003', '2016-08-10', 'Quae repudiandae fugiat', 500000, 0, 1, '2016-08-10 10:41:03'),
('M000004', '2016-08-15', 'Consectetur adipisicing', 750000, 0, 1, '2016-08-15 10:51:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `is_users`
--

CREATE TABLE `is_users` (
  `id_user` smallint(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telepon` varchar(12) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `level` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` enum('aktif','blokir') NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `is_users`
--

INSERT INTO `is_users` (`id_user`, `username`, `nama_lengkap`, `password`, `email`, `telepon`, `foto`, `level`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Agus Kurniawan', '21232f297a57a5a743894a0e4a801fc3', 'admin@xbxteam.web.id', '082154805956', 'Ags.jpg', 'admin', 'aktif', '2016-05-01 08:42:53', '2019-04-14 10:42:39'),
(2, 'user', 'User', 'ee11cbb19052e40b07aac0ca060c23ee', 'user@gmail.com', '085680892909', 'kadina.png', 'user', 'aktif', '2016-08-01 08:42:53', '2019-04-14 10:38:51');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `is_kas`
--
ALTER TABLE `is_kas`
  ADD PRIMARY KEY (`no_kwitansi`),
  ADD KEY `created_user` (`created_user`);

--
-- Indeks untuk tabel `is_users`
--
ALTER TABLE `is_users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `level` (`level`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `is_kas`
--
ALTER TABLE `is_kas`
  ADD CONSTRAINT `is_kas_ibfk_1` FOREIGN KEY (`created_user`) REFERENCES `is_users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
