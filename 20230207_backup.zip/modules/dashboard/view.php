


        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <i style="margin-right: 7px" class="fa fa-dashboard"></i> Dashboard
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-lg-12 col-xs-12">
              <div style="background-color: #dff0d8 !important;" class="alert alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p style="font-size:15px">
                  <i class="icon fa fa-user"></i> Selamat datang <strong><?php echo $_SESSION['nama_lengkap']; ?></strong>.
                </p>        
              </div>
            </div>
          </div>

          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <?php  
                  try {
                    // sql statement untuk menampilkan data dari tabel is_kas
                    $query = "SELECT SUM(penerimaan) as jumlah FROM is_kas";
                    // membuat prepared statements
                    $stmt = $pdo->prepare($query);
                    // eksekusi query
                    $stmt->execute();

                    // tampilkan data
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);

                    $total_penerimaan = $data['jumlah'];
                  } catch (PDOException $e) {
                    // tampilkan pesan kesalahan
                    echo "ada kesalahan pada query : ".$e->getMessage();
                  }
                  ?>
                  <h3>Rp. <?php echo format_rupiah($total_penerimaan); ?></h3>
                  <p>Total Penerimaan</p>
                </div>
                <div class="icon">
                  <i class="fa fa-sign-in"></i>
                </div>
                <a href="?module=penerimaan" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <?php  
                  try {
                    // sql statement untuk menampilkan data dari tabel is_kas
                    $query = "SELECT SUM(pengeluaran) as jumlah FROM is_kas";
                    // membuat prepared statements
                    $stmt = $pdo->prepare($query);
                    // eksekusi query
                    $stmt->execute();

                    // tampilkan data
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);

                    $total_pengeluaran = $data['jumlah'];
                  } catch (PDOException $e) {
                    // tampilkan pesan kesalahan
                    echo "ada kesalahan pada query : ".$e->getMessage();
                  }
                  ?>
                  <h3>Rp. <?php echo format_rupiah($total_pengeluaran); ?></h3>
                  <p>Total Pengeluaran</p>
                </div>
                <div class="icon">
                  <i class="fa fa-sign-out"></i>
                </div>
                <a href="?module=pengeluaran" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <?php  
                  $saldo = $total_penerimaan - $total_pengeluaran;
                  ?>
                  <h3>Rp. <?php echo format_rupiah($saldo); ?></h3>
                  <p>Saldo</p>
                </div>
                <div class="icon">
                  <i class="fa fa-dollar"></i>
                </div>
                <a href="?module=lap_rekapitulasi" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            
            
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <?php  
                  try {
                    // sql statement untuk menampilkan data dari tabel is_kas
                    $query = "SELECT SUM(jumlah_keluarga) as jumlah_keluarga FROM is_users";
                    // membuat prepared statements
                    $stmt = $pdo->prepare($query);
                    // eksekusi query
                    $stmt->execute();

                    // tampilkan data
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);

                    $jumlah_keluarga = $data['jumlah_keluarga'];
                  } catch (PDOException $e) {
                    // tampilkan pesan kesalahan
                    echo "ada kesalahan pada query : ".$e->getMessage();
                  }
                  ?>
                  <h3><?php echo $jumlah_keluarga; ?></h3>
                  <p>Jumlah Warga QN</p>
                </div>
                <div class="icon">
                  <i class="fa fa-user"></i>
                </div>
                <a href="?module=warga" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            
            
            
            
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <?php  
                  try {
                    // sql statement untuk menampilkan data dari tabel is_kas
                    $query = "SELECT count(status) as jumlah_kk FROM is_users where status = 'aktif'";
                    // membuat prepared statements
                    $stmt = $pdo->prepare($query);
                    // eksekusi query
                    $stmt->execute();

                    // tampilkan data
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);

                    $jumlah_kk = $data['jumlah_kk'];
                  } catch (PDOException $e) {
                    // tampilkan pesan kesalahan
                    echo "ada kesalahan pada query : ".$e->getMessage();
                  }
                  ?>
                  <h3><?php echo $jumlah_kk; ?></h3>
                  <p>Jumlah Kepala Keluarga (KK)</p>
                </div>
                <div class="icon">
                  <i class="fa fa-user"></i>
                </div>
                <a href="?module=warga" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            
            
            
            
            <?php  
            if ($_SESSION['level']=='admin') {  
              try {
                // sql statement untuk menampilkan data dari tabel is_users
                $query = "SELECT COUNT(id_user) as jumlah FROM is_users";
                // membuat prepared statements
                $stmt = $pdo->prepare($query);

                // eksekusi query
                $stmt->execute();

                // tampilkan data
                $data = $stmt->fetch(PDO::FETCH_ASSOC);

                $jumlah_user = $data['jumlah'];
              } catch (PDOException $e) {
                // tampilkan pesan kesalahan
                echo "ada kesalahan pada query : ".$e->getMessage();
              }
            ?>
              <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                  <div class="inner">
                    <h3><?php echo $jumlah_user; ?></h3>
                    <p>User Terdaftar</p>
                  </div>
                  <div class="icon">
                    <i class="fa fa-user"></i>
                  </div>
                  <a href="?module=user" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div><!-- ./col -->
              
            <?php
            } elseif ($_SESSION['level']=='user') { ?>
              <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                  <div class="inner">
                    <h3><span style="color:transparent">.</span></h3>
                    <p>Grafik</p>
                  </div>
                  <div class="icon">
                    <i class="fa fa-bar-chart"></i>
                  </div>
                  <a href="?module=grafik" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div><!-- ./col -->
              
              
            <?php
            } elseif ($_SESSION['level']=='warga') { ?>
              <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                  <div class="inner">
                    <h3><span style="color:transparent">.</span></h3>
                    <p>Grafik</p>
                  </div>
                  <div class="icon">
                    <i class="fa fa-bar-chart"></i>
                  </div>
                  <a href="?module=grafik" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div><!-- ./col -->
            <?php
            }
            ?>
          </div><!-- /.row -->
          
          <br>

          <div class="row">
            <div class="col-md-6 col-lg-6 col-xs-12">
              <div style="background-color: #dff0d8 !important;" class="alert alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p style="font-size:15px">
                  <?php  
                  try {
                    $hari_ini = date("Y-m-d");
                    // sql statement untuk menampilkan data dari tabel is_kas
                    $query = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE tanggal=:tanggal";
                    // membuat prepared statements
                    $stmt = $pdo->prepare($query);
                    // mengikat parameter 
                    $stmt->bindParam(':tanggal', $hari_ini);
                    // eksekusi query
                    $stmt->execute();

                    // tampilkan data
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);

                    $penerimaan = $data['jumlah'];
                  } catch (PDOException $e) {
                    // tampilkan pesan kesalahan
                    echo "ada kesalahan pada query : ".$e->getMessage();
                  }
                  ?>
                  <i class="icon fa fa-sign-in"></i> Penerimaan hari ini : <strong>Rp. <?php echo format_rupiah($penerimaan); ?></strong>
                </p>        
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6 col-lg-6 col-xs-12">
              <div style="background-color: #dff0d8 !important;" class="alert alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p style="font-size:15px">
                  <?php  
                  try {
                    // sql statement untuk menampilkan data dari tabel is_kas
                    $query = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE tanggal=:tanggal";
                    // membuat prepared statements
                    $stmt = $pdo->prepare($query);
                    // mengikat parameter 
                    $stmt->bindParam(':tanggal', $hari_ini);
                    // eksekusi query
                    $stmt->execute();

                    // tampilkan data
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);

                    $pengeluaran = $data['jumlah'];
                  } catch (PDOException $e) {
                    // tampilkan pesan kesalahan
                    echo "ada kesalahan pada query : ".$e->getMessage();
                  }
                  ?>
                  <i class="icon fa fa-sign-out"></i> Pengeluaran hari ini : <strong>Rp. <?php echo format_rupiah($pengeluaran); ?></strong>
                </p>        
              </div>
            </div>
          </div>
        </section><!-- /.content -->