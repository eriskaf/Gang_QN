<!-- -->
<?php  
if ($_GET['form']=='add') { ?>
  <!-- tampilan form add data -->
	<!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i style="margin-right:7px" class="fa fa-edit"></i> Input Iuran Sampah QN
    </h1>
    <ol class="breadcrumb">
      <li><a href="?module=dashboard"><i class="fa fa-home"></i> Home </a></li>
      <li><a href="?module=iuran-sampah"> Iuran Sampah </a></li>
      <li class="active"> Input </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <!-- form start -->
          <form role="form" class="form-horizontal" method="POST" action="modules/iuran-sampah/proses.php?act=insert">
            <div class="box-body">

              <div class="form-group">
                <label class="col-sm-2 control-label">Tanggal</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy" name="tanggal" autocomplete="off" required>
                </div>
              </div>
              
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Bulan</label>
                <div class="col-sm-5">
                  <select type="text" class="form-control" name="bulan" autocomplete="off" value="<?php echo $bulan; ?>" required>
                        <option value="">- Pilih bulan -</option>
                        <option value="01">Januari</option>
                        <option value="02">Februari</option>
                        <option value="03">Maret</option>
                        <option value="04">April</option>
                        <option value="05">Mei</option>
                        <option value="06">Juni</option>
                        <option value="07">Juli</option>
                        <option value="08">Agustus</option>
                        <option value="09">September</option>
                        <option value="10">Oktober</option>
                        <option value="11">November</option>
                        <option value="12">Desember</option>
                    </select>
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Tahun</label>
                <div class="col-sm-5">
                  <select type="text" class="form-control" name="tahun" autocomplete="off" value="<?php echo $tahun; ?>" required>
                        <option value="">- Pilih tahun -</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                        <option value="2026">2026</option>
                        <option value="2027">2027</option>
                        <option value="2028">2028</option>
                        <option value="2029">2029</option>
                        <option value="2030">2030</option>
                        <option value="2031">2031</option>
                        <option value="2032">2032</option>
                        <option value="2033">2033</option>
                        <option value="2034">2034</option>
                        <option value="2035">2035</option>
                    </select>    
                </div>
              </div>
 
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Nama</label>
                <div class="col-sm-5">
                    <select type="text" class="form-control" name="nama_lengkap" autocomplete="off" value="<?php echo $nama_lengkap; ?>" required>
                        <option value="">- Pilih Nama -</option>
                        <option value="Sanfiar">Sanfiar</option>
                        <option value="Hanafi">Hanafi</option>
                        <option value="Dodi">Dodi</option>
                        <option value="Heri">Heri</option>
                        <option value="Sandra">Sandra</option>
                        <option value="Ganesa">Ganesa</option>
                        <option value="Eron">Eron</option>
                        <option value="Rokhman">Rokhman</option>
                        <option value="Eris">Eris</option>
                        <option value="Abdul">Abdul</option>
                        <option value="Bowo">Bowo</option>
                        <option value="Reza">Reza</option>
                        <option value="Faisal">Faisal</option>
                        <option value="Zuki">Zuki</option>
                        <option value="Puji">Puji</option>
                        <option value="Mariani">Mariani</option>
                        <option value="Agung">Agung</option>
                        <option value="Rahagia">Rahagia</option>
                        <option value="Rusli">Rusli</option>
                        <option value="Ali">Ali</option>
                        <option value="Putra">Putra</option>
                        <option value="rickyn130">Ricky</option>
                        <option value="Hendrik">Hendrik</option>
                        <option value="Hendi">Hendi</option>
                        <option value="Mercy">Mercy</option>
                        <option value="Ivan">Ivan</option>
                        <option value="Ismir">Ismir</option>
                        <option value="Rudi">Rudi</option>
                        <option value="Bambang">Bambang</option>
                        <option value="Taufik">Taufik</option>
                        <option value="Haris">Haris</option>
                        <option value="Yusuf">Yusuf</option>
                  </select>
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Keterangan</label>
                <div class="col-sm-5">
                  <textarea type="text" class="form-control" name="keterangan" rows="2" required></textarea>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Iuran Sampah</label>
                <div class="col-sm-5">
                  <div class="input-group">
                    <span class="input-group-addon">Rp.</span>
                    <input type="text" class="form-control" id="jumlah1" name="jumlah1" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)">
                  </div>
                </div>
              </div>
              
              
               <div class="form-group">
                <label class="col-sm-2 control-label">Iuran Kas</label>
                <div class="col-sm-5">
                  <div class="input-group">
                    <span class="input-group-addon">Rp.</span>
                    <input type="text" class="form-control" id="jumlah" name="jumlah2" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)">
                  </div>
                </div>
              </div>
              
              
            </div><!-- /.box body -->

            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
                  <a href="?module=iuran-sampah" class="btn btn-default btn-reset">Batal</a>
                </div>
              </div>
            </div><!-- /.box footer -->
          </form>
        </div><!-- /.box -->
      </div><!--/.col -->
    </div>   <!-- /.row -->
  </section><!-- /.content -->
  
  
  
  
<?php
}

// jika form edit data yang dipilih
elseif ($_GET['form']=='edit') { 
  	if (isset($_GET['id'])) {
	    try {
			// sql statement untuk menampilkan data dari tabel is_sampah berdasarkan nama_lengkap
			$query = "SELECT no_kwitansi, tanggal, bulan, tahun, keterangan, penerimaan_sampah, penerimaan_kas, total_penerimaan, nama_lengkap FROM is_sampah WHERE no_kwitansi = :no_kwitansi";
			// membuat prepared statements
			$stmt = $pdo->prepare($query);

			//mengikat parameter 
			$stmt->bindParam(':no_kwitansi', $_GET['id']);

			// eksekusi query
			$stmt->execute();

			// mengambil data user
			$data = $stmt->fetch(PDO::FETCH_ASSOC);

			// nilai untuk mengisi form
			$no_kwitansi     = $data['no_kwitansi'];
			$tanggal     = $data['tanggal'];
			$bulan       = $data['bulan'];
			$tahun        = $data['tahun'];
			$keterangan        = $data['keterangan'];
			$penerimaan_sampah      = $data['penerimaan_sampah'];
			$penerimaan_kas      = $data['penerimaan_kas'];
			$total_penerimaan      = $data['total_penerimaan'];
			$nama_lengkap         = $data['nama_lengkap'];

			// tutup koneksi database
			$pdo = null;
	    } catch (PDOException $e) {
			// tampilkan pesan kesalahan
			echo "ada kesalahan pada query : ".$e->getMessage();
	    }
  	}	
?>
	<!-- tampilkan form edit data -->
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i style="margin-right:7px" class="fa fa-edit"></i> Ubah Data Iuran Sampah
    </h1>
    <ol class="breadcrumb">
      <li><a href="?module=dashboard"><i class="fa fa-home"></i> Home</a></li>
      <li><a href="?module=iuran-sampah"> Iuran Sampah </a></li>
      <li class="active"> Ubah </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <!-- form start -->
          <form role="form" class="form-horizontal" method="POST" action="modules/iuran-sampah/proses.php?act=update" enctype="multipart/form-data">
            <div class="box-body">

             
              <input type="hidden" name="no_kwitansi" value="<?php echo $no_kwitansi; ?>">

              <div class="form-group">
                <label class="col-sm-2 control-label">Tanggal</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy" name="tanggal" autocomplete="off" required>
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Bulan</label>
                <div class="col-sm-5">
                  <select type="text" class="form-control" name="bulan" autocomplete="off" value="<?php echo $bulan; ?>" required>
                        <option value=""></option>
                        <option value="01">Januari</option>
                        <option value="02">Februari</option>
                        <option value="03">Maret</option>
                        <option value="04">April</option>
                        <option value="05">Mei</option>
                        <option value="06">Juni</option>
                        <option value="07">Juli</option>
                        <option value="08">Agustus</option>
                        <option value="09">September</option>
                        <option value="10">Oktober</option>
                        <option value="11">November</option>
                        <option value="12">Desember</option>
                    </select>
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Tahun</label>
                <div class="col-sm-5">
                  <select type="text" class="form-control" name="tahun" autocomplete="off" value="<?php echo $tahun; ?>" required>
                        <option value=""></option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                        <option value="2026">2026</option>
                        <option value="2027">2027</option>
                        <option value="2028">2028</option>
                        <option value="2029">2029</option>
                        <option value="2030">2030</option>
                        <option value="2031">2031</option>
                        <option value="2032">2032</option>
                        <option value="2033">2033</option>
                        <option value="2034">2034</option>
                        <option value="2035">2035</option>
                    </select>    
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Nama</label>
                <div class="col-sm-5">
                    <select type="text" class="form-control" name="nama_lengkap" autocomplete="off" value="<?php echo $nama_lengkap; ?>" required>
                        <option value=""></option>
                        <option value="Sanfiar">Sanfiar</option>
                        <option value="Hanafi">Hanafi</option>
                        <option value="Dodi">Dodi</option>
                        <option value="Heri">Heri</option>
                        <option value="Sandra">Sandra</option>
                        <option value="Ganesa">Ganesa</option>
                        <option value="Khoeron">Khoeron</option>
                        <option value="Rokhman">Rokhman</option>
                        <option value="Eris">Eris</option>
                        <option value="Abdul">Abdul</option>
                        <option value="Bowo">Bowo</option>
                        <option value="Reza">Reza</option>
                        <option value="faisal">faisal</option>
                        <option value="Zuki">Zuki</option>
                        <option value="Puji">Puji</option>
                        <option value="Mariani">Mariani</option>
                        <option value="Agung">Agung</option>
                        <option value="Rahagia">Rahagia</option>
                        <option value="Rusli">Rusli</option>
                        <option value="Ali">Ali</option>
                        <option value="Putra">Putra</option>
                        <option value="Ricky">Ricky</option>
                        <option value="Hendrik">Hendrik</option>
                        <option value="Hendi">Hendi</option>
                        <option value="Mercy">Mercy</option>
                        <option value="Ivan">Ivan</option>
                        <option value="Ismir">Ismir</option>
                        <option value="Rudi">Rudi</option>
                        <option value="Bambang">Bambang</option>
                        <option value="Taufik">Taufik</option>
                        <option value="Haris">Haris</option>
                        <option value="Yusuf">Yusuf</option>
                  </select>
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Keterangan</label>
                <div class="col-sm-5">
                  <textarea type="text" class="form-control" name="keterangan" rows="2" required></textarea>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Iuran Sampah</label>
                <div class="col-sm-5">
                  <div class="input-group">
                    <span class="input-group-addon">Rp.</span>
                    <input type="text" class="form-control" id="jumlah1" name="jumlah1" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)" required>
                  </div>
                </div>
              </div>
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Iuran Kas</label>
                <div class="col-sm-5">
                  <div class="input-group">
                    <span class="input-group-addon">Rp.</span>
                    <input type="text" class="form-control" id="jumlah2" name="jumlah2" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)" required>
                  </div>
                </div>
              </div>
              
              
        
            </div><!-- /.box body -->
            
            

            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
                  <a href="?module=iuran-sampah" class="btn btn-default btn-reset">Batal</a>
                </div>
              </div>
            </div><!-- /.box footer -->
          </form>
        </div><!-- /.box -->
      </div><!--/.col -->
    </div>   <!-- /.row -->
  </section><!-- /.content -->
<?php
}
?>