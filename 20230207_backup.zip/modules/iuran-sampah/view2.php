
   
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <i style="margin-right:7px" class="fa fa-sign-in"></i> Iuran Sampah QN

   
   </h1>
 

</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">
        

    <?php  
    // fungsi untuk menampilkan pesan
    // jika alert = "" (kosong)
    // tampilkan pesan "" (kosong)
    if (empty($_GET['alert'])) {
      echo "";
    } 
    // jika alert = 1
    // tampilkan pesan Sukses "data iuran kas berhasil disimpan"
    elseif ($_GET['alert'] == 1) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              data iuran sampah qn berhasil disimpan.
            </div>";
    }
    // jika alert = 2
    // tampilkan pesan Gagal "No. Kwitansi sudah ada"
    elseif ($_GET['alert'] == 2) {
      echo "<div class='alert alert-danger alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-times-circle'></i> Gagal!</h4>
              No. Kwitansi $_GET[no] sudah ada.
            </div>";
    }
    ?>

      <div class="box box-success">
        <div class="box-body">
            <div class="scroll">
          <!-- tampilan tabel iuran sampah qn -->
          <table id="dataTables1" class="table table-bordered table-striped table-hover">
            <!-- tampilan tabel header -->
            <thead>
              <tr class="filters">
                <th class="center">No.</th>
                <th class="center">No. Kwitansi</th>
                <th class="center">Tanggal</th>
                <th class="center">Bulan</th>
                <th class="center">Tahun</th>
                <th class="center">Bulan-Tahun</th>
                <th class="center">Nama</th>
                <th class="center">Keterangan</th>
                <th class="center">Iuran Sampah</th>
                <th class="center">Iuran Kas</th>
                <th class="center">Total Iuran</th>
                <th class="center">Created by</th>
                
                
              </tr>
            </thead>
            <!-- tampilan tabel body -->
            <tbody>
            <?php  
            try {
              $no = 1;
              $kosong = "0";
              // sql statement untuk menampilkan data dari tabel is_sampah
              $query = "SELECT a.no_kwitansi, a.tanggal, a.bulan, a.tahun, concat(a.tahun,'-',a.bulan) as bulantahun, a.keterangan, a.penerimaan_sampah, a.penerimaan_kas, (a.penerimaan_sampah+a.penerimaan_kas) as total_penerimaan, a.nama_lengkap, b.username FROM is_sampah as a inner join is_users as b on a.created_user = b.id_user
                        WHERE a.tanggal!=:kosong
                        ORDER BY a.no_kwitansi DESC, a.bulan DESC, a.tahun DESC
                        ";
              // membuat prepared statements
              $stmt = $pdo->prepare($query);
              // mengikat parameter 
              $stmt->bindParam(':kosong', $kosong);
              // eksekusi query
              $stmt->execute();

              // tampilkan data
              while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // format tanggal
                $tgl     = $data['tanggal'];
                $explode = explode('-',$tgl);
                $tanggal = tgl_eng_to_ind($explode[2]."-".$explode[1]."-".$explode[0]);
                // format rupiah
                $jumlah1 = format_rupiah($data['penerimaan_sampah']);
                $jumlah2 = format_rupiah($data['penerimaan_kas']);
                $jumlah3 = format_rupiah($data['total_penerimaan']);
                
               
                // menampilkan isi tabel dari database ke tabel di aplikasi
                echo "<tr>
                        <td width='40' class='center'>$no</td>
                        <td width='50' class='center'>$data[no_kwitansi]</td>
                        <td width='120'>$tanggal</td>
                        <td width='40'>$data[bulan]</td>
                        <td width='60'>$data[tahun]</td>
                        <td width='80'>$data[bulantahun]</td>
                        <td width='150'>$data[nama_lengkap]</td>
                        <td width='200'>$data[keterangan]</td>
                        <td width='100' class='right'>Rp. $jumlah1</td>
                        <td width='100' class='right'>Rp. $jumlah2</td>
                        <td width='120' class='right'>Rp. $jumlah3</td>
                        
                        <td width='100'>$data[username]</td>
                        
                
                      </tr>";
                      
                      
                $no++;
              }
              
             
              
              

              // tutup koneksi database
              $pdo = null;
            } catch (PDOException $e) {
              // tampilkan pesan kesalahan
              echo "ada kesalahan pada query : ".$e->getMessage();
            }
            ?>
            </tbody>
          </table>
          </div>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!--/.col -->
  </div>   <!-- /.row -->
</section><!-- /.content