
   
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    <i style="margin-right:7px" class="fa fa-sign-in"></i> Penerimaan Kas

    <a class="btn btn-success btn-social pull-right" href="?module=form_penerimaan" title="Tambah Data" data-toggle="tooltip">
      <i class="fa fa-plus"></i> Tambah
    </a>
  </h1>

</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-md-12">

    <?php  
    // fungsi untuk menampilkan pesan
    // jika alert = "" (kosong)
    // tampilkan pesan "" (kosong)
    if (empty($_GET['alert'])) {
      echo "";
    } 
    // jika alert = 1
    // tampilkan pesan Sukses "data penerimaan kas berhasil disimpan"
    elseif ($_GET['alert'] == 1) {
      echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              data penerimaan kas berhasil disimpan.
            </div>";
    }
    // jika alert = 2
    // tampilkan pesan Gagal "No. Kwitansi sudah ada"
    elseif ($_GET['alert'] == 2) {
      echo "<div class='alert alert-danger alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-times-circle'></i> Gagal!</h4>
              No. Kwitansi $_GET[no] sudah ada.
            </div>";
    }
    ?>

      <div class="box box-success">
        <div class="box-body">
            <div class="scroll">
          <!-- tampilan tabel penerimaan kas -->
          <table id="dataTables1" class="table table-bordered table-striped table-hover">
              
            <!-- tampilan tabel header -->
            <thead>
                
              <tr>
                <th class="center">No.</th>
                <th class="center">No. Kwitansi</th>
                <th class="center">Tanggal</th>
                <th class="center">Keterangan</th>
                <th class="center">Jumlah</th>
                <th class="center">Created by</th>
              </tr>
            </thead>
            <!-- tampilan tabel body -->
            <tbody>
            <?php  
            try {
              $no = 1;
              $kosong = "0";
              // sql statement untuk menampilkan data dari tabel is_kas
              $query = "SELECT a.no_kwitansi, a.tanggal, a.keterangan, a.penerimaan, b.nama_lengkap FROM is_kas as a inner join is_users as b on a.created_user = b.id_user
                        WHERE a.penerimaan!=:kosong
                        ORDER BY a.tanggal DESC, a.no_kwitansi DESC";
              // membuat prepared statements
              $stmt = $pdo->prepare($query);
              // mengikat parameter 
              $stmt->bindParam(':kosong', $kosong);
              // eksekusi query
              $stmt->execute();

              // tampilkan data
              while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // format tanggal
                $tgl     = $data['tanggal'];
                $explode = explode('-',$tgl);
                $tanggal = tgl_eng_to_ind($explode[2]."-".$explode[1]."-".$explode[0]);
                // format rupiah
                $jumlah = format_rupiah($data['penerimaan']);
                // menampilkan isi tabel dari database ke tabel di aplikasi
                echo "<tr>
                        <td width='50' class='center'>$no</td>
                        <td width='150' class='center'>$data[no_kwitansi]</td>
                        <td width='170'>$tanggal</td>
                        <td width='350'>$data[keterangan]</td>
                        <td width='200' class='right'>Rp. $jumlah</td>
                        <td width='170'>$data[nama_lengkap]</td>
                      </tr>";
                $no++;
              }

              // tutup koneksi database
              $pdo = null;
            } catch (PDOException $e) {
              // tampilkan pesan kesalahan
              echo "ada kesalahan pada query : ".$e->getMessage();
            }
            ?>
            </tbody>
          </table>
          </div>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!--/.col -->
  </div>   <!-- /.row -->
</section><!-- /.content