<!-- -->


<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../config/database.php";

// fungsi untuk pengecekan status login user 
// jika user belum login, alihkan ke halaman login dan tampilkan pesan = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])){
	echo "<meta http-equiv='refresh' content='0; url=index.php?alert=1'>";
}
// jika user sudah login, maka jalankan perintah untuk insert data
else {
	// insert data
	if (isset($_POST['simpan'])) {
		// ambil data hasil submit dari form
		
		
		// fungsi untuk membuat no_kwitansi
			try {
				// sql statement untuk menampilkan data dari tabel is_kas berdasarkan no_kwitansi
				$query = "SELECT max(no_kwitansi) as kode FROM is_kas";
				// membuat prepared statements
				$stmt = $pdo->prepare($query);

				// eksekusi query
				$stmt->execute();

				// mengambil data user
				$data = $stmt->fetch(PDO::FETCH_ASSOC);

				// nilai untuk mengisi form
				$no_kwitansi = $data['kode'] + 1;

			} catch (PDOException $e) {
				// tampilkan pesan kesalahan
				echo "ada kesalahan pada query id user : ".$e->getMessage();
			}
			
			
		
		$tgl         = $_POST['tanggal'];
		$explode     = explode('-',$tgl);
		$tanggal     = $explode[2]."-".$explode[1]."-".$explode[0];
		
		$keterangan  = trim($_POST['keterangan']);
		$jumlah      = str_replace('.', '', trim($_POST['jumlah']));

		// ambil data dari session
		$user = $_SESSION['id_user'];

		try {
			// sql statement untuk seleksi no_kwitansi dari tabel is_kas
			$query = "SELECT no_kwitansi FROM is_kas WHERE no_kwitansi=:no_kwitansi";
			// membuat prepared statements
			$stmt = $pdo->prepare($query);

			// mengikat parameter
			$stmt->bindParam(':no_kwitansi', $no_kwitansi);

			// eksekusi query
			$stmt->execute();

			$count = $stmt->rowCount();
			// jika no_kwitansi sudah ada
			if($count > 0) {
				// tampilkan pesan no_kwitansi sudah ada
				header("location: ../../main.php?module=pengeluaran&no=$no_kwitansi&alert=2");
			}
			// jika no_kwitansi belum ada
			else {
				// sql statement untuk menyimpan data ke tabel is_kas
		        $query = "INSERT INTO is_kas(no_kwitansi,tanggal,keterangan,pengeluaran,created_user)	
						  VALUES(:no_kwitansi,:tanggal,:keterangan,:pengeluaran,:created_user)";
		        // membuat prepared statements
		        $stmt = $pdo->prepare($query);

		        // mengikat parameter
				$stmt->bindParam(':no_kwitansi', $no_kwitansi);
				$stmt->bindParam(':tanggal', $tanggal);
				$stmt->bindParam(':keterangan', $keterangan);
				$stmt->bindParam(':pengeluaran', $jumlah);
				$stmt->bindParam(':created_user', $user);

				// eksekusi query
		        $stmt->execute();

		        // jika berhasil tampilkan pesan berhasil simpan data
				header("location: ../../main.php?module=pengeluaran&alert=1");
			}

			// tutup koneksi database
	        $pdo = null;
		} catch (PDOException $e) {
			// tampilkan pesan kesalahan
	        echo "ada kesalahan pada query insert : ".$e->getMessage();
		}	
	}	
}		
?>