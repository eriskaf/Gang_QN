

<?php  
// fungsi untuk pengecekan tampilan form
// jika form add data yang dipilih
if ($_GET['form']=='add') { ?>
  <!-- tampilkan form add data -->
	<!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i style="margin-right:7px" class="fa fa-edit"></i> Input User
    </h1>
    <ol class="breadcrumb">
      <li><a href="?module=dashboard"><i class="fa fa-home"></i> Home </a></li>
      <li><a href="?module=user"> User </a></li>
      <li class="active"> Input </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <!-- form start -->
          <form role="form" class="form-horizontal" method="POST" action="modules/user/proses.php?act=insert" enctype="multipart/form-data">
            <div class="box-body">

              <div class="form-group">
                <label class="col-sm-2 control-label">Username</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" name="username" autocomplete="off" required>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Password</label>
                <div class="col-sm-5">
                  <input type="password" class="form-control" name="password" autocomplete="off" required>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Nama Lengkap</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" name="nama_lengkap" autocomplete="off" required>
                </div>
              </div>
            </div><!-- /.box body -->

            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
                  <a href="?module=user" class="btn btn-default btn-reset">Batal</a>
                </div>
              </div>
            </div><!-- /.box footer -->
          </form>
        </div><!-- /.box -->
      </div><!--/.col -->
    </div>   <!-- /.row -->
  </section><!-- /.content -->
<?php
}

// jika form edit data yang dipilih
elseif ($_GET['form']=='edit') { 
  	if (isset($_GET['id'])) {
	    try {
			// sql statement untuk menampilkan data dari tabel is_users berdasarkan id_user
			$query = "SELECT id_user, username, nama_lengkap, level, email, telepon, foto FROM is_users WHERE id_user = :id_user";
			// membuat prepared statements
			$stmt = $pdo->prepare($query);

			//mengikat parameter 
			$stmt->bindParam(':id_user', $_GET['id']);

			// eksekusi query
			$stmt->execute();

			// mengambil data user
			$data = $stmt->fetch(PDO::FETCH_ASSOC);

			// nilai untuk mengisi form
			$id_user      = $data['id_user'];
			$username     = $data['username'];
			$nama_lengkap = $data['nama_lengkap'];
			$level        = $data['level'];
			$email        = $data['email'];
			$telepon      = $data['telepon'];
			$foto         = $data['foto'];

			// tutup koneksi database
			$pdo = null;
	    } catch (PDOException $e) {
			// tampilkan pesan kesalahan
			echo "ada kesalahan pada query : ".$e->getMessage();
	    }
  	}	
?>
	<!-- tampilkan form edit data -->
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i style="margin-right:7px" class="fa fa-edit"></i> Ubah Data User
    </h1>
    <ol class="breadcrumb">
      <li><a href="?module=dashboard"><i class="fa fa-home"></i> Home</a></li>
      <li><a href="?module=user"> User </a></li>
      <li class="active"> Ubah </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <!-- form start -->
          <form role="form" class="form-horizontal" method="POST" action="modules/user/proses.php?act=update" enctype="multipart/form-data">
            <div class="box-body">

              <input type="hidden" name="id_user" value="<?php echo $id_user; ?>">

              <div class="form-group">
                <label class="col-sm-2 control-label">Username</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" name="username" autocomplete="off" value="<?php echo $username; ?>" required>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Password</label>
                <div class="col-sm-5">
                  <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Kosongkan password jika tidak diubah">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Nama Lengkap</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" name="nama_lengkap" autocomplete="off" value="<?php echo $nama_lengkap; ?>" required>
                </div>
              </div>
              
              
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Level</label>
                <div class="col-sm-5">
                  <select type="text" class="form-control" name="level" autocomplete="off" value="<?php echo $level; ?>" required>
                      <option value="">- level apa? -</option>
                      <option value="admin">admin</option>
                      <option value="user">user</option>
                      <option value="warga">warga</option>
                      </select>
                </div>
              </div>
              
              

              <div class="form-group">
                <label class="col-sm-2 control-label">Email</label>
                <div class="col-sm-5">
                  <input type="email" class="form-control" name="email" autocomplete="off" value="<?php echo $email; ?>">
                </div>
              </div>
            
              <div class="form-group">
                <label class="col-sm-2 control-label">Telepon</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="12" onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $telepon; ?>">
                </div>
              </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Foto</label>
                <div class="col-sm-5">
                  <input type="file" name="foto">
                  <br/>
                <?php  
                if ($foto=="") { ?>
                  <img style="border:1px solid #eaeaea;border-radius:5px;" src="images/user/user-default.png" width="128">
                <?php
                }
                else { ?>
                  <img style="border:1px solid #eaeaea;border-radius:5px;" src="images/user/<?php echo $foto; ?>" width="128">
                <?php
                }
                ?>
                </div>
              </div>
            </div><!-- /.box body -->

            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
                  <a href="?module=user" class="btn btn-default btn-reset">Batal</a>
                </div>
              </div>
            </div><!-- /.box footer -->
          </form>
        </div><!-- /.box -->
      </div><!--/.col -->
    </div>   <!-- /.row -->
  </section><!-- /.content -->
<?php
}
?>