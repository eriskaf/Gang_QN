-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2023 at 05:05 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `i_kas`
--

-- --------------------------------------------------------

--
-- Table structure for table `is_kas`
--

CREATE TABLE `is_kas` (
  `no_kwitansi` varchar(7) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `penerimaan` int(11) NOT NULL DEFAULT 0,
  `pengeluaran` int(11) NOT NULL DEFAULT 0,
  `created_user` smallint(6) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `is_kas`
--

INSERT INTO `is_kas` (`no_kwitansi`, `tanggal`, `keterangan`, `penerimaan`, `pengeluaran`, `created_user`, `created_date`) VALUES
('0000001', '2023-01-21', 'uang kas dari pak rahagia', 150000, 0, 1, '2023-01-21 02:17:33'),
('001', '2019-06-26', 'fee', 20000000, 0, 1, '2019-06-26 07:33:15'),
('1232141', '2023-01-21', 'aaaaaaaaaaaaaaaaaaaaaaa', 0, 2000000, 1, '2023-01-21 03:55:43'),
('77777', '2019-06-02', 'fee Marketing Vlatava 2', 16000000, 0, 1, '2019-06-02 03:51:33'),
('K000001', '2016-08-03', 'Lorem ipsum dolor sit amet', 0, 200000, 1, '2016-08-03 05:23:14'),
('K000002', '2016-08-10', 'At quia quaerat asperiores', 0, 100000, 1, '2016-08-10 03:49:59'),
('K000003', '2016-08-15', 'quaerat asperiores ipsum', 0, 250000, 1, '2016-11-20 03:57:15'),
('M000001', '2016-08-01', 'Consectetur adipisicing elit', 1000000, 0, 1, '2016-08-01 05:23:14'),
('M000002', '2016-08-07', 'Optio corporis quae nulla', 500000, 0, 1, '2016-08-07 05:24:27'),
('M000003', '2016-08-10', 'Quae repudiandae fugiat', 500000, 0, 1, '2016-08-10 03:41:03'),
('M000004', '2016-08-15', 'Consectetur adipisicing', 750000, 0, 1, '2016-08-15 03:51:26');

-- --------------------------------------------------------

--
-- Table structure for table `is_users`
--

CREATE TABLE `is_users` (
  `id_user` smallint(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telepon` varchar(12) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `level` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` enum('aktif','blokir') NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `is_users`
--

INSERT INTO `is_users` (`id_user`, `username`, `nama_lengkap`, `password`, `email`, `telepon`, `foto`, `level`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Eriska Febrianto', '877adeebfbfc1f2bb3059c677d40d482', 'eriska.f@gmail.com', '081310008555', 'IMG_20220504_192230a.jpg', 'admin', 'aktif', '2016-05-01 01:42:53', '2023-01-21 02:11:46'),
(2, 'user', 'User', 'ee11cbb19052e40b07aac0ca060c23ee', 'user@gmail.com', '085680892909', 'kadina.png', 'user', 'aktif', '2016-08-01 01:42:53', '2019-04-14 03:38:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `is_kas`
--
ALTER TABLE `is_kas`
  ADD PRIMARY KEY (`no_kwitansi`),
  ADD KEY `created_user` (`created_user`);

--
-- Indexes for table `is_users`
--
ALTER TABLE `is_users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `level` (`level`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `is_kas`
--
ALTER TABLE `is_kas`
  ADD CONSTRAINT `is_kas_ibfk_1` FOREIGN KEY (`created_user`) REFERENCES `is_users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
