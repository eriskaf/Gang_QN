<!-- -->


  <?php  
  if (isset($_POST['tahun'])) {
    $tahun = $_POST['tahun'];
  } else {
    $tahun = "";
  }

  if (isset($_POST['tahun'])) {
    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='1' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahjan1 = 0;
    } else {
      $jumlahjan1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='1' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahjan2 = 0;
    } else {
      $jumlahjan2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='2' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
  // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahfeb1 = 0;
    } else {
      $jumlahfeb1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='2' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahfeb2 = 0;
    } else {
      $jumlahfeb2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------
    
    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='3' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahmar1 = 0;
    } else {
      $jumlahmar1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='3' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahmar2 = 0;
    } else {
      $jumlahmar2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------
    
    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='4' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahapr1 = 0;
    } else {
      $jumlahapr1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='4' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahapr2 = 0;
    } else {
      $jumlahapr2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------
    
    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='5' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahmei1 = 0;
    } else {
      $jumlahmei1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='5' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahmei2 = 0;
    } else {
      $jumlahmei2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='6' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahjun1 = 0;
    } else {
      $jumlahjun1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='6' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahjun2 = 0;
    } else {
      $jumlahjun2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='7' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahjul1 = 0;
    } else {
      $jumlahjul1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='7' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahjul2 = 0;
    } else {
      $jumlahjul2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='8' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahags1 = 0;
    } else {
      $jumlahags1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='8' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahags2 = 0;
    } else {
      $jumlahags2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='9' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahsep1 = 0;
    } else {
      $jumlahsep1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='9' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahsep2 = 0;
    } else {
      $jumlahsep2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='10' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahokt1 = 0;
    } else {
      $jumlahokt1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='10' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahokt2 = 0;
    } else {
      $jumlahokt2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------

    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='11' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahnov1 = 0;
    } else {
      $jumlahnov1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='11' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahnov2 = 0;
    } else {
      $jumlahnov2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------
    
    $query1 = "SELECT SUM(penerimaan) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='12' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahdes1 = 0;
    } else {
      $jumlahdes1 = $data1['jumlah'];
    }

    $query1 = "SELECT SUM(pengeluaran) as jumlah FROM is_kas WHERE EXTRACT(MONTH FROM tanggal)='12' AND EXTRACT(YEAR FROM tanggal)='$tahun'";
    // membuat prepared statements
    $stmt = $pdo->prepare($query1);
    // eksekusi query
    $stmt->execute();
    // tampilkan data
    $data1 = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($data1['jumlah']=='') {
      $jumlahdes2 = 0;
    } else {
      $jumlahdes2 = $data1['jumlah'];
    }
    // -------------------------------------------------------------------------------------------------------------------------------------
  }
  ?>
  
  <script src="assets/plugins/highcharts/jquery.min.js"></script>
  <script src="assets/plugins/highcharts/highcharts.js"></script>

  <script type="text/javascript">
  var chart1; // globally available
  $(document).ready(function() {
      chart1 = new Highcharts.Chart({
          chart: {
              renderTo: 'kas',
              type: 'line'
          },   
          title: {
              text: 'Grafik Penerimaan dan Pengeluaran Kas Tahun <?php echo $tahun; ?>'
          },
          xAxis: {
              categories: ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']
          },
          yAxis: {
              title: {
                 text: 'Jumlah'
              },
              plotLines: [{
                  value: 0,
                  width: 1,
                  color: '#808080'
              }]
          },
          tooltip: { 
              //fungsi tooltip, ini opsional, kegunaan dari fungsi ini 
              //akan menampikan data di titik tertentu di grafik saat mouseover
              formatter: function() {
                      return '<b>Bulan: '+ this.x +'</b><br/>'+'Jumlah : Rp. '+ this.y;
              }
          },
              series:             
              [{
                  name: 'Penerimaan',
                  data: [<?php echo $jumlahjan1; ?>,<?php echo $jumlahfeb1; ?>,<?php echo $jumlahmar1; ?>,<?php echo $jumlahapr1; ?>,<?php echo $jumlahmei1; ?>,<?php echo $jumlahjun1; ?>,<?php echo $jumlahjul1; ?>,<?php echo $jumlahags1; ?>,<?php echo $jumlahsep1; ?>,<?php echo $jumlahokt1; ?>,<?php echo $jumlahnov1; ?>,<?php echo $jumlahdes1; ?>]
              },
              {
                  name: 'Pengeluaran',
                  data: [<?php echo $jumlahjan2; ?>,<?php echo $jumlahfeb2; ?>,<?php echo $jumlahmar2; ?>,<?php echo $jumlahapr2; ?>,<?php echo $jumlahmei2; ?>,<?php echo $jumlahjun2; ?>,<?php echo $jumlahjul2; ?>,<?php echo $jumlahags2; ?>,<?php echo $jumlahsep2; ?>,<?php echo $jumlahokt2; ?>,<?php echo $jumlahnov2; ?>,<?php echo $jumlahdes2; ?>]
              }
              ]
        });
     });  
  </script>

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i style="margin-right:7px" class="fa fa-bar-chart"></i> Grafik
    </h1>
    <ol class="breadcrumb">
      <li><a href="?module=dashboard"><i class="fa fa-home"></i> Home </a></li>
      <li class="active"> Grafik </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <!-- Form Laporan Penerimaan Kas -->
        <div class="box box-success">
          <!-- form start -->
          <form role="form" class="form-horizontal" method="POST" action="?module=grafik">
            <div class="box-body">

              <div class="form-group">
                <label class="col-sm-1 control-label">Tahun</label>
                <div class="col-sm-3">
                  <select class="form-control" name="tahun" required>
                    <option value="<?php echo $tahun; ?>"><?php echo $tahun; ?></option>
                    <?php
                    try {
                      // sql statement untuk menampilkan data dari tabel is_kas
                      $query = "SELECT distinct(EXTRACT(YEAR FROM tanggal)) as tahun 
                                FROM is_kas ORDER BY tahun DESC";
                      // membuat prepared statements
                      $stmt = $pdo->prepare($query);
                      // eksekusi query
                      $stmt->execute();
                      // tampilkan data
                      while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo"<option value=\"$data[tahun]\"> $data[tahun] </option>";
                      }
                    } catch (PDOException $e) {
                      // tampilkan pesan kesalahan
                      echo "ada kesalahan pada query : ".$e->getMessage();
                    }
                    ?>
                  </select>
                </div>
                
                <div class="col-sm-4">
                  <button style="width:100px" type="submit" class="btn btn-success">
                    Tampilkan
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div><!-- /.box -->
      </div><!--/.col -->
    </div>   <!-- /.row -->

    <div class="row">
      <?php
      if (isset($_POST['tahun'])) { ?>
        <div class="col-md-12">
          <!-- Form Laporan Penerimaan Kas -->
          <div class="box">
            <br>
            <!-- form start -->
            <div id="kas" style="height:450px;max-width:95%;"></div>
          </div><!-- /.box -->
        </div><!--/.col -->
      <?php
      }
      ?>
    </div>   <!-- /.row -->
  </section><!-- /.content -->