<!-- -->


  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i style="margin-right:7px" class="fa fa-file-text-o"></i> Laporan Penerimaan Kas
    </h1>
    <ol class="breadcrumb">
      <li><a href="?module=dashboard"><i class="fa fa-home"></i> Home </a></li>
      <li><a href="?module=lap_penerimaan"> Laporan </a></li>
      <li class="active"> Penerimaan Kas </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12">

      <?php  
      // fungsi untuk menampilkan pesan
      // jika alert = "" (kosong)
      // tampilkan pesan "" (kosong)
      if (empty($_GET['alert'])) {
        echo "";
      } 
      // jika alert = 1
      // tampilkan pesan Sukses "data user baru berhasil disimpan"
      elseif ($_GET['alert'] == 1) {
        echo "<div class='alert alert-warning alert-dismissable'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4>  <i class='icon fa fa-exclamation-circle'></i> Peringatan!</h4>
                Periode Laporan belum ditentukan.
              </div>";
      }
      ?>
        <!-- Form Laporan Penerimaan Kas -->
        <div class="box box-success">
          <!-- form start -->
          <form role="form" class="form-horizontal" name="frmLaporan" method="GET" action="modules/lap-penerimaan/cetak.php" target="_blank">
            <div class="box-body">

              <div class="form-group">
                <label class="col-sm-2">
                  <input type="radio" name="filter" value="tanggal" onClick="radio_option()" /> Per Tanggal
                </label>
                <div class="col-sm-3">
                  <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy" name="tanggal" autocomplete="off" required disabled="">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2">
                  <input type="radio" name="filter" value="bulan" onClick="radio_option()" /> Per Bulan
                </label>
                <div class="col-sm-3">
                  <select class="form-control" name="bulan" disabled="" required>
                    <option value="">- Pilih Bulan -</option>
                    <option value="1">Januari</option>
                    <option value="2">Februari</option>
                    <option value="3">Maret</option>
                    <option value="4">April</option>
                    <option value="5">Mei</option>
                    <option value="6">Juni</option>
                    <option value="7">Juli</option>
                    <option value="8">Agustus</option>
                    <option value="9">September</option>
                    <option value="10">Oktober</option>
                    <option value="11">November</option>
                    <option value="12">Desember</option>
                  </select>
                </div>
                <div class="col-sm-2">
                  <select class="form-control" name="tahun1" disabled="" required>
                    <option value="">- Pilih Tahun -</option>
                    <?php
                    try {
                      // sql statement untuk menampilkan data dari tabel is_kas
                      $query = "SELECT distinct(EXTRACT(YEAR FROM tanggal)) as tahun 
                                FROM is_kas ORDER BY tahun DESC";
                      // membuat prepared statements
                      $stmt = $pdo->prepare($query);
                      // eksekusi query
                      $stmt->execute();
                      // tampilkan data
                      while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo"<option value=\"$data[tahun]\"> $data[tahun] </option>";
                      }
                    } catch (PDOException $e) {
                      // tampilkan pesan kesalahan
                      echo "ada kesalahan pada query : ".$e->getMessage();
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2">
                  <input type="radio" name="filter" value="tahun" onClick="radio_option()" /> Per Tahun
                </label>
                <div class="col-sm-3">
                  <select class="form-control" name="tahun2" disabled="" required>
                    <option value="">- Pilih Tahun -</option>
                    <?php
                    try {
                      // sql statement untuk menampilkan data dari tabel is_kas
                      $query = "SELECT distinct(EXTRACT(YEAR FROM tanggal)) as tahun 
                                FROM is_kas ORDER BY tahun DESC";
                      // membuat prepared statements
                      $stmt = $pdo->prepare($query);
                      // eksekusi query
                      $stmt->execute();
                      // tampilkan data
                      while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo"<option value=\"$data[tahun]\"> $data[tahun] </option>";
                      }
                    } catch (PDOException $e) {
                      // tampilkan pesan kesalahan
                      echo "ada kesalahan pada query : ".$e->getMessage();
                    }
                    ?>
                  </select>
                </div>
              </div>
            </div>
            
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-success btn-social btn-submit">
                    <i class="fa fa-print"></i> Cetak
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div><!-- /.box -->
      </div><!--/.col -->
    </div>   <!-- /.row -->
  </section><!-- /.content -->