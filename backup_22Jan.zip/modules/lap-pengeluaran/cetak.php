<?php
session_start();
ob_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../config/database.php";
// panggil fungsi untuk format tanggal
include "../../config/fungsi_tanggal.php";
// panggil fungsi untuk format rupiah
include "../../config/fungsi_rupiah.php";

$hari_ini = date("d-m-Y");

try {

    $no    = 1;
    $total = 0;
    // jika filter laporan tidak ada yang dipilih
    if (empty($_GET['filter'])) {
        // tampilkan pesan pilih filter
        header("location: ../../main.php?module=lap_pengeluaran&alert=1");
    }
    // jika laporan per tanggal dipilih
    elseif ($_GET['filter']=="tanggal") {
        // ambil data hasil submit dari form
        $tgl     = $_GET['tanggal'];
        $explode = explode('-',$tgl);
        $tanggal = $explode[2]."-".$explode[1]."-".$explode[0];

        $kosong  = "0";

        // sql statement untuk menampilkan data dari tabel is_kas
        $query = "SELECT no_kwitansi, tanggal, keterangan, pengeluaran FROM is_kas 
                  WHERE pengeluaran!=:kosong AND tanggal=:tanggal
                  ORDER BY tanggal ASC, no_kwitansi ASC";

        // membuat prepared statements
        $stmt = $pdo->prepare($query);
        // mengikat parameter 
        $stmt->bindParam(':kosong', $kosong);
        $stmt->bindParam(':tanggal', $tanggal);
    }
    // jika laporan per bulan dipilih
    elseif ($_GET['filter']=="bulan") {
        // ambil data hasil submit dari form
        $bulan  = $_GET['bulan'];
        $tahun1 = $_GET['tahun1'];
        
        $kosong = "0";

        // sql statement untuk menampilkan data dari tabel is_kas
        $query = "SELECT no_kwitansi, tanggal, keterangan, pengeluaran FROM is_kas 
                  WHERE pengeluaran!=:kosong AND EXTRACT(MONTH FROM tanggal)=:bulan AND EXTRACT(YEAR FROM tanggal)=:tahun
                  ORDER BY tanggal ASC, no_kwitansi ASC";

        // membuat prepared statements
        $stmt = $pdo->prepare($query);
        // mengikat parameter 
        $stmt->bindParam(':kosong', $kosong);
        $stmt->bindParam(':bulan', $bulan);
        $stmt->bindParam(':tahun', $tahun1);
    }
    // jika laporan per tahun dipilih
    elseif ($_GET['filter']=="tahun") {
        // ambil data hasil submit dari form
        $tahun2 = $_GET['tahun2'];
        
        $kosong = "0";

        // sql statement untuk menampilkan data dari tabel is_kas
        $query = "SELECT no_kwitansi, tanggal, keterangan, pengeluaran FROM is_kas 
                  WHERE pengeluaran!=:kosong AND EXTRACT(YEAR FROM tanggal)=:tahun
                  ORDER BY tanggal ASC, no_kwitansi ASC";

        // membuat prepared statements
        $stmt = $pdo->prepare($query);
        // mengikat parameter 
        $stmt->bindParam(':kosong', $kosong);
        $stmt->bindParam(':tahun', $tahun2);
    }
    
    // eksekusi query
    $stmt->execute();

    $count = $stmt->rowCount();
?>
<html xmlns="http://www.w3.org/1999/xhtml"> <!-- Bagian halaman HTML yang akan konvert -->
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Laporan Pengeluaran Kas</title>
        <link rel="stylesheet" type="text/css" href="../../assets/css/laporan.css" />
    </head>
    <body>
        <div id="title">
            LAPORAN PENGELUARAN KAS 
        </div>
    <?php  
    if ($_GET['filter']=="tanggal") { ?>
        <div id="title-tanggal">
            Tanggal <?php echo tgl_eng_to_ind($tgl); ?>
        </div>
    <?php
    }
    elseif ($_GET['filter']=="bulan") { 
        if ($bulan == 1) {
            $bln = "Januari";
        } 
        elseif ($bulan == 2) {
            $bln = "Februari";
        } 
        elseif ($bulan == 3) {
            $bln = "Maret";
        }
        elseif ($bulan == 4) {
            $bln = "April";
        }
        elseif ($bulan == 5) {
            $bln = "Mei";
        }
        elseif ($bulan == 6) {
            $bln = "Juni";
        }
        elseif ($bulan == 7) {
            $bln = "Juli";
        }
        elseif ($bulan == 8) {
            $bln = "Agustus";
        }
        elseif ($bulan == 9) {
            $bln = "September";
        }
        elseif ($bulan == 10) {
            $bln = "Oktober";
        }
        elseif ($bulan == 11) {
            $bln = "November";
        }
        elseif ($bulan == 12) {
            $bln = "Desember";
        }

        $thn1 = $tahun1;
    ?>
        <div id="title-tanggal">
            Bulan <?php echo $bln; ?> Tahun <?php echo $thn1; ?>
        </div>
    <?php
    }
    elseif ($_GET['filter']=="tahun") { ?>
        <div id="title-tanggal">
            Tahun <?php echo $tahun2; ?>
        </div>
    <?php
    }
    ?>
        

        <hr><br>
        <div id="isi">
            <table width="100%" border="0.3" cellpadding="0" cellspacing="0">
                <thead style="background:#e8ecee">
                    <tr class="tr-title">
                        <th height="20" align="center" valign="middle">No.</th>
                        <th height="20" align="center" valign="middle">No. Kwintansi</th>
                        <th height="20" align="center" valign="middle">Tanggal</th>
                        <th height="20" align="center" valign="middle">Keterangan</th>
                        <th height="20" align="center" valign="middle">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
<?php
    // jika data ada
    if($count == 0) {
        echo "  <tr>
                    <td width='50' height='13' align='center' valign='middle'></td>
                    <td width='100' height='13' align='center' valign='middle'></td>
                    <td style='padding-left:5px;' width='140' height='13' valign='middle'></td>
                    <td style='padding-left:5px;' width='248' height='13' valign='middle'></td>
                    <td style='padding-right:5px;' width='130' height='13' align='right' valign='middle'></td>
                </tr>
                <tr>
                    <td height='15' colspan='4' align='center' valign='middle'><strong>Total Pengeluaran</strong></td>
                    <td style='padding-right:5px;' height='15' width='130' align='right' valign='middle'><strong></strong></td>
                </tr>";
    }
    // jika data tidak ada
    else {
        // tampilkan data
        while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $tgl     = $data['tanggal'];
            $explode = explode('-',$tgl);
            $tanggal = tgl_eng_to_ind($explode[2]."-".$explode[1]."-".$explode[0]);
            
            $jumlah = $data['pengeluaran'];
            // menampilkan isi tabel dari database ke tabel di aplikasi
            echo "  <tr>
                        <td width='50' height='13' align='center' valign='middle'>$no</td>
                        <td width='100' height='13' align='center' valign='middle'>$data[no_kwitansi]</td>
                        <td style='padding-left:5px;' width='140' height='13' valign='middle'>$tanggal</td>
                        <td style='padding-left:5px;' width='248' height='13' valign='middle'>$data[keterangan]</td>
                        <td style='padding-right:5px;' width='130' height='13' align='right' valign='middle'>Rp. ".format_rupiah($jumlah)."</td>
                    </tr>";
            $no++;

            $total += $jumlah;
        }
            echo "  <tr>
                        <td height='15' colspan='4' align='center' valign='middle'><strong>Total Pengeluaran</strong></td>
                        <td style='padding-right:5px;' height='15' width='130' align='right' valign='middle'><strong>Rp. ".format_rupiah($total)."</strong></td>
                    </tr>";
    }
    // tutup koneksi database
    $pdo = null;
} catch (PDOException $e) {
    // tampilkan pesan kesalahan
    echo "ada kesalahan pada query : ".$e->getMessage();
}
?>	
                </tbody>
            </table>

            <div id="footer-tanggal">
                Jakarta, <?php echo tgl_eng_to_ind("$hari_ini"); ?>
            </div>
            <div id="footer-jabatan">
                Ketua QN,
            </div>
            
            <div id="footer-nama">
                Bambang
            </div>
        </div>
    </body>
</html><!-- Akhir halaman HTML yang akan di konvert -->
<?php
$filename="Laporan Pengeluaran Kas.pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
//==========================================================================================================
$content = ob_get_clean();
$content = '<page style="font-family: freeserif">'.($content).'</page>';
// panggil library html2pdf
require_once('../../assets/plugins/html2pdf_v4.03/html2pdf.class.php');
try
{
    $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(10, 10, 10, 10));
    $html2pdf->setDefaultFont('Arial');
    $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
    $html2pdf->Output($filename);
}
catch(HTML2PDF_exception $e) { echo $e; }
?>