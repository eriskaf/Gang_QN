<!-- -->


<?php 
// fungsi pengecekan level untuk menampilkan menu sesuai dengan level
// jika level = admin, tampilkan menu
if ($_SESSION['level']=='admin') { ?>
	<!-- sidebar menu start -->
    <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>

	<?php 
	// fungsi untuk pengecekan menu aktif
	// jika menu dashboard dipilih, menu dashboard aktif
	if ($_GET["module"]=="dashboard") {
		echo '	<li class="active">
					<a href="?module=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
			  	</li>';
	}
	// jika tidak, menu dashboard tidak aktif
	else {
		echo '	<li>
					<a href="?module=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
			  	</li>';
	}

	// jika menu penerimaan dipilih, menu penerimaan aktif
	if ($_GET["module"]=="penerimaan" || $_GET["module"]=="form_penerimaan") {
		echo '	<li class="active">
					<a href="?module=penerimaan"><i class="fa fa-sign-in"></i> Penerimaan</a>
			  	</li>';
	}
	// jika tidak, menu penerimaan tidak aktif
	else {
		echo '	<li>
					<a href="?module=penerimaan"><i class="fa fa-sign-in"></i> Penerimaan</a>
			  	</li>';
	}

	// jika menu pengeluaran dipilih, menu pengeluaran aktif
	if ($_GET["module"]=="pengeluaran" || $_GET["module"]=="form_pengeluaran") {
		echo '	<li class="active">
					<a href="?module=pengeluaran"><i class="fa fa-sign-out"></i> Pengeluaran</a>
			  	</li>';
	}
	// jika tidak, menu pengeluaran tidak aktif
	else {
		echo '	<li>
					<a href="?module=pengeluaran"><i class="fa fa-sign-out"></i> Pengeluaran</a>
			  	</li>';
	}

	// jika menu lap penerimaan dipilih, menu lap penerimaan aktif
	if ($_GET["module"]=="lap_penerimaan") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li class="active"><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika menu lap pengeluaran dipilih, menu lap pengeluaran aktif
	elseif ($_GET["module"]=="lap_pengeluaran") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li class="active"><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika menu lap rekapitulasi dipilih, menu lap rekapitulasi aktif
	elseif ($_GET["module"]=="lap_rekapitulasi") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li class="active"><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika tidak, menu laporan tidak aktif
	else {
		echo '	<li class="treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}

	// jika menu grafik dipilih, menu grafik aktif
	if ($_GET["module"]=="grafik") {
		echo '	<li class="active">
					<a href="?module=grafik"><i class="fa fa-bar-chart"></i> Grafik</a>
				</li>';
	}
	// jika tidak, menu grafik tidak aktif
	else {
		echo '	<li>
					<a href="?module=grafik"><i class="fa fa-bar-chart"></i> Grafik</a>
				</li>';
	}

	// jika menu user dipilih, menu user aktif
	if ($_GET["module"]=="user" || $_GET["module"]=="form_user") {
		echo '	<li class="active">
					<a href="?module=user"><i class="fa fa-user"></i> Manajemen User</a>
				</li>';
	}
	// jika tidak, menu user tidak aktif
	else {
		echo '	<li>
					<a href="?module=user"><i class="fa fa-user"></i> Manajemen User</a>
				</li>';
	}

	// jika menu ubah password dipilih, menu ubah password aktif
	if ($_GET["module"]=="password") {
		echo '	<li class="active">
					<a href="?module=password"><i class="fa fa-lock"></i> Ubah Password</a>
				</li>';
	}
	// jika tidak, ubah password tidak aktif
	else {
		echo '	<li>
					<a href="?module=password"><i class="fa fa-lock"></i> Ubah Password</a>
				</li>';
	}
	?>
	</ul>
	<!--sidebar menu end-->
<?php
}



// jika level = user, tampilkan menu
elseif ($_SESSION['level']=='user') { ?>
	<!-- sidebar menu start -->
    <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>

	<?php 
	// fungsi untuk pengecekan menu aktif
	// jika menu dashboard dipilih, menu dashboard aktif
	if ($_GET["module"]=="dashboard") {
		echo '	<li class="active">
					<a href="?module=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
			  	</li>';
	}
	// jika tidak, menu dashboard tidak aktif
	else {
		echo '	<li>
					<a href="?module=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
			  	</li>';
	}

	// jika menu penerimaan dipilih, menu penerimaan aktif
	if ($_GET["module"]=="penerimaan" || $_GET["module"]=="form_penerimaan") {
		echo '	<li class="active">
					<a href="?module=penerimaan"><i class="fa fa-sign-in"></i> Penerimaan</a>
			  	</li>';
	}
	// jika tidak, menu penerimaan tidak aktif
	else {
		echo '	<li>
					<a href="?module=penerimaan"><i class="fa fa-sign-in"></i> Penerimaan</a>
			  	</li>';
	}

	// jika menu pengeluaran dipilih, menu pengeluaran aktif
	if ($_GET["module"]=="pengeluaran" || $_GET["module"]=="form_pengeluaran") {
		echo '	<li class="active">
					<a href="?module=pengeluaran"><i class="fa fa-sign-out"></i> Pengeluaran</a>
			  	</li>';
	}
	// jika tidak, menu pengeluaran tidak aktif
	else {
		echo '	<li>
					<a href="?module=pengeluaran"><i class="fa fa-sign-out"></i> Pengeluaran</a>
			  	</li>';
	}

	// jika menu lap penerimaan dipilih, menu lap penerimaan aktif
	if ($_GET["module"]=="lap_penerimaan") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li class="active"><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika menu lap pengeluaran dipilih, menu lap pengeluaran aktif
	elseif ($_GET["module"]=="lap_pengeluaran") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li class="active"><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika menu lap rekapitulasi dipilih, menu lap rekapitulasi aktif
	elseif ($_GET["module"]=="lap_rekapitulasi") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li class="active"><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika tidak, menu laporan tidak aktif
	else {
		echo '	<li class="treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}

	// jika menu grafik dipilih, menu grafik aktif
	if ($_GET["module"]=="grafik") {
		echo '	<li class="active">
					<a href="?module=grafik"><i class="fa fa-bar-chart"></i> Grafik</a>
				</li>';
	}
	// jika tidak, menu grafik tidak aktif
	else {
		echo '	<li>
					<a href="?module=grafik"><i class="fa fa-bar-chart"></i> Grafik</a>
				</li>';
	}

	// jika menu ubah password dipilih, menu ubah password aktif
	if ($_GET["module"]=="password") {
		echo '	<li class="active">
					<a href="?module=password"><i class="fa fa-lock"></i> Ubah Password</a>
				</li>';
	}
	// jika tidak, ubah password tidak aktif
	else {
		echo '	<li>
					<a href="?module=password"><i class="fa fa-lock"></i> Ubah Password</a>
				</li>';
	}
	?>
	</ul>
	<!--sidebar menu end-->
<?php
}




// jika level = warga, tampilkan menu
elseif ($_SESSION['level']=='warga') { ?>
	<!-- sidebar menu start -->
    <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>

	<?php 
	// fungsi untuk pengecekan menu aktif
	// jika menu dashboard dipilih, menu dashboard aktif
	if ($_GET["module"]=="dashboard") {
		echo '	<li class="active">
					<a href="?module=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
			  	</li>';
	}
	// jika tidak, menu dashboard tidak aktif
	else {
		echo '	<li>
					<a href="?module=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>
			  	</li>';
	}

	
	// jika menu penerimaan dipilih, menu penerimaan aktif
	if ($_GET["module"]=="penerimaan2" || $_GET["module"]=="form_penerimaan") {
		echo '	<li class="active">
					<a href="?module=penerimaan2"><i class="fa fa-sign-in"></i> Penerimaan</a>
			  	</li>';
	}
	// jika tidak, menu penerimaan tidak aktif
	else {
		echo '	<li>
					<a href="?module=penerimaan2"><i class="fa fa-sign-in"></i> Penerimaan</a>
			  	</li>';
	}
	
	
	
	// jika menu pengeluaran dipilih, menu pengeluaran aktif
	if ($_GET["module"]=="pengeluaran2" || $_GET["module"]=="form_pengeluaran") {
		echo '	<li class="active">
					<a href="?module=pengeluaran2"><i class="fa fa-sign-out"></i> Pengeluaran</a>
			  	</li>';
	}
	// jika tidak, menu pengeluaran tidak aktif
	else {
		echo '	<li>
					<a href="?module=pengeluaran2"><i class="fa fa-sign-out"></i> Pengeluaran</a>
			  	</li>';
	}
	
	
	
	// jika menu lap penerimaan dipilih, menu lap penerimaan aktif
	if ($_GET["module"]=="lap_penerimaan") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li class="active"><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika menu lap pengeluaran dipilih, menu lap pengeluaran aktif
	elseif ($_GET["module"]=="lap_pengeluaran") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li class="active"><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika menu lap rekapitulasi dipilih, menu lap rekapitulasi aktif
	elseif ($_GET["module"]=="lap_rekapitulasi") {
		echo '	<li class="active treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li class="active"><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}
	// jika tidak, menu laporan tidak aktif
	else {
		echo '	<li class="treeview">
	              	<a href="javascript:void(0);">
	                	<i class="fa fa-file-text"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
	              	</a>
              		<ul class="treeview-menu">
                		<li><a href="?module=lap_penerimaan"><i class="fa fa-circle-o"></i> Penerimaan</a></li>
                		<li><a href="?module=lap_pengeluaran"><i class="fa fa-circle-o"></i> Pengeluaran</a></li>
                		<li><a href="?module=lap_rekapitulasi"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
              		</ul>
            	</li>';
	}

	// jika menu grafik dipilih, menu grafik aktif
	if ($_GET["module"]=="grafik") {
		echo '	<li class="active">
					<a href="?module=grafik"><i class="fa fa-bar-chart"></i> Grafik</a>
				</li>';
	}
	// jika tidak, menu grafik tidak aktif
	else {
		echo '	<li>
					<a href="?module=grafik"><i class="fa fa-bar-chart"></i> Grafik</a>
				</li>';
	}

	// jika menu ubah password dipilih, menu ubah password aktif
	if ($_GET["module"]=="password") {
		echo '	<li class="active">
					<a href="?module=password"><i class="fa fa-lock"></i> Ubah Password</a>
				</li>';
	}
	// jika tidak, ubah password tidak aktif
	else {
		echo '	<li>
					<a href="?module=password"><i class="fa fa-lock"></i> Ubah Password</a>
				</li>';
	}
	?>
	</ul>
	

	
	<!--sidebar menu end-->
<?php
}



?>